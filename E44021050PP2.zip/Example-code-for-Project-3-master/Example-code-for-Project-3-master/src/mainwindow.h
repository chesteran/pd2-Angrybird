#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QList>
#include <QDesktopWidget>
#include <QTimer>
#include <Box2D/Box2D.h>
#include <QMouseEvent>
#include <iostream>
#include <QtCore>
#include <QtGui>
#include <gameitem.h>
#include <land.h>
#include <bird.h>
#include<wall.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void showEvent(QShowEvent *);
    bool eventFilter(QObject *,QEvent *event);
    void closeEvent(QCloseEvent *);
    int X1,X2,Y1,Y2;
    int x,y;
    int speedx,speedy,speed;
    int birdnum;
    bool mux;
    int bb=1;
    int count=0;
    void restart();
    void score();
    //void qquit();
    //void score();
signals:
    // Signal for closing the game
    void quitGame();

private slots:
    void tick();
    // For debug slot
    void QUITSLOT();
private:
    Ui::MainWindow *ui;
    QGraphicsScene *scene;
    b2World *world;
    QList<GameItem *> itemList;
    QTimer timer;

    Bird *greenbird ;//1
     Bird *birdie;//2
     Bird *eggbird;//3
     Bird *yellowbird;//4
     Bird *pig1;
     Bird *pig2;
     Bird *pig3;
     wall *wwall_1;
     wall *wwall_2;
     wall *wwall_3;
     wall *wwall_4;
     wall *wwall_5;
     wall *wwall_6;
    //void keyPressEvent(QKeyEvent *event);
     //Bird *wall;
     void keyPressEvent(QKeyEvent *event);
 // void score(QKeyEvent *event);
};

#endif // MAINWINDOW_H
