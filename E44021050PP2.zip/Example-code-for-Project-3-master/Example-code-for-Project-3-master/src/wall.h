#ifndef WALL_H
#define WALL_H
#include <gameitem.h>
#include <QPixmap>
#include <QGraphicsScene>
#include <QTimer>

#define wall_DENSITY 3.9f
#define wall_FRICTION 0.02f
#define wall_RESTITUTION 0.5f

class wall : public GameItem
{
public:

    wall(float x, float y, float w, float h, QTimer *timer, QPixmap pixmap, b2World *world, QGraphicsScene *scene);
    void setLinearVelocity(b2Vec2 velocity);
};

#endif // WALL_H




