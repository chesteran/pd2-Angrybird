#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMainWindow>
#include <QDebug>
#include <QtCore>
#include <QLabel>
#include <QBrush>
#include <QPixmap>
#include <QWidget>
#include <QBitmap>
#include <QKeyEvent>
#include <QTime>
#include <QPainter>
#include <QCoreApplication>
#include <ctime>
#include <QDialog>
#include <QMovie>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    X1=0;
    X2=0;
    Y1=0;
    Y2=0;
    birdnum=1;
    speed=6;
    mux=false;
 //   x=0;y=0;
    ui->setupUi(this);
    // Enable the event Filter
    qApp->installEventFilter(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showEvent(QShowEvent *)
{


    // Setting the QGraphicsScene
    scene = new QGraphicsScene(0,0,width(),ui->graphicsView->height());
    ui->graphicsView->setScene(scene);
    // Create world
    world = new b2World(b2Vec2(0.0f, -9.8f));
    // Setting Size
    GameItem::setGlobalSize(QSizeF(32,18),size());
    // Create ground (You can edit here)
    itemList.push_back(new Land(16,1.5,32,3,QPixmap(":/ground.png").scaled(width(),height()/6.0),world,scene));
   // itemList.push_back(new Land(3,3,5,5,QPixmap(":/image/horbarrier.png").scaled(width()/8,height()/6.0),world,scene));
    wwall_1 = new wall(20.0f,6.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_2 = new wall(20.0f,12.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_3 = new wall(10.0f,6.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_4 = new wall(15.0f,6.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_5 = new wall(20.0f,18.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_6 = new wall(30.0f,6.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    // Create bird (You can edit here)
    greenbird = new Bird(3.0f,5.0f,0.27f,&timer,QPixmap(":/image/GGbird.png").scaled(height()/9.0,height()/9.0),world,scene);

    pig1 = new Bird(22.0f,5.0f,0.27f,&timer,QPixmap(":/image/PPig.png").scaled(height()/9.0,height()/9.0),world,scene);
    pig2 = new Bird(27.0f,5.0f,0.27f,&timer,QPixmap(":/image/PPig.png").scaled(height()/9.0,height()/9.0),world,scene);
    pig3 = new Bird(12.0f,5.0f,0.27f,&timer,QPixmap(":/image/PPig.png").scaled(height()/9.0,height()/9.0),world,scene);
    // Setting the Velocity
  /*  if(eventFilter(birdie,QEvent::MouseButtonRelease)){
    birdie->setLinearVelocity(b2Vec2(x,y));
    }
    greenbird->setLinearVelocity(b2Vec2(0,0.1));*/

   // yellowbird->setLinearVelocity(b2Vec2(0,0.1));
    //eggbird->setLinearVelocity(b2Vec2(0,0.1));
   // pig->setLinearVelocity(b2Vec2(0,0.1));

   std::cout << "x="<<X1<<" "<<X2<<"y="<<Y1<<" "<<Y2<< std::endl ;
    itemList.push_back(birdie);
    // Timer
    connect(&timer,SIGNAL(timeout()),this,SLOT(tick()));
    connect(this,SIGNAL(quitGame()),this,SLOT(QUITSLOT()));
    timer.start(100/6);
  //  timer.start(100/speed);

}

bool MainWindow::eventFilter(QObject *, QEvent *event)
{
//int mux=0;
    // Hint: Notice the Number of every event!
    if(event->type() == QEvent::MouseButtonPress &&!mux )
    {

     X1=QCursor::pos().x();
     Y1=QCursor::pos().y();

        /* TODO : add your code here */
        //std::cout << "Press !" << std::endl ;
    }
    if(event->type() == QEvent::MouseMove)
    {
        /* TODO : add your code here */
        //std::cout << "Move !" << std::endl ;
    }
    if(event->type() == QEvent::MouseButtonRelease && !mux)
    {

        X2=QCursor::pos().x();
        Y2=QCursor::pos().y();
        x=X1-X2;
        y=Y1-Y2;
         if(x>50){
             x=50;
         }
         else if(x<=0){
             x=0;
         }
         if(y>50){
             std::cout<<"y="<<y<<std::endl;
             y=50;
             std::cout<<"y="<<y<<std::endl;
         }

        switch(birdnum){
        case 1:
            greenbird->setLinearVelocity(b2Vec2(x,y));
     //       birdie = new Bird(3.0f,5.0f,0.27f,&timer,QPixmap(":/bird.png").scaled(height()/9.0,height()/9.0),world,scene);
            score();
            break;
          case 2:
            greenbird->setLinearVelocity(b2Vec2(x+10,0));
            score();
            break;
        case 3:
      //      birdie = new Bird(3.0f,5.0f,0.27f,&timer,QPixmap(":/bird.png").scaled(height()/9.0,height()/9.0),world,scene);
            greenbird->~QObject();
            birdie->setLinearVelocity(b2Vec2(x,y));
            score();
      //      yellowbird = new Bird(3.0f,5.0f,0.27f,&timer,QPixmap(":/image/YYbird.png").scaled(height()/9.0,height()/9.0),world,scene);
            break;
        case 4:
          //  birdie->setLinearVelocity(b2Vec2(x+10,0));
            score();
            break;
        case 5:
            birdie->~QObject();
            yellowbird->setLinearVelocity(b2Vec2(x,y));
            score();
      //      eggbird = new Bird(3.0f,5.0f,0.27f,&timer,QPixmap(":/image/EEbird.png").scaled(height()/9.0,height()/9.0),world,scene);
            break;
        case 6:
            score();
            yellowbird->setLinearVelocity(b2Vec2(x-10,0));
            break;
        case 7:
            yellowbird->~QObject();
            eggbird ->setLinearVelocity(b2Vec2(x,y));
            score();
            break;
        case 8:
            eggbird->setLinearVelocity(b2Vec2(x,-10));
            score();
            break;
        }
        // Timer
        connect(&timer,SIGNAL(timeout()),this,SLOT(tick()));
        connect(this,SIGNAL(quitGame()),this,SLOT(QUITSLOT()));
        timer.start(500/speed);

        switch(birdnum){
        case 1:
            birdie = new Bird(3.0f,3.0f,0.27f,&timer,QPixmap(":/bird.png").scaled(height()/9.0,height()/9.0),world,scene);
            break;
        case 3:
     //       birdie = new Bird(3.0f,5.0f,0.27f,&timer,QPixmap(":/bird.png").scaled(height()/9.0,height()/9.0),world,scene);
          //  greenbird->~QObject();

            yellowbird = new Bird(3.0f,3.0f,0.27f,&timer,QPixmap(":/image/YYbird.png").scaled(height()/9.0,height()/9.0),world,scene);
            break;
        case 5:
      //      birdie->~QObject();

            eggbird = new Bird(3.0f,3.0f,0.27f,&timer,QPixmap(":/image/EEbird.png").scaled(height()/9.0,height()/9.0),world,scene);
            break;
        case 7:
     //       yellowbird->~QObject();
            break;
        }
          //   birdnum++;
             mux=true;
       // birdie->setLinearVelocity(b2Vec2(x,y));
        /* TODO : add your code here */
      //  std::cout << "Release !" << std::endl ;
             return true;
    }
    if(event->type() == QEvent::MouseButtonPress && mux){
/*
if(bb==1){
    greenbird->setLinearVelocity(b2Vec2(x+10,0));}
 else if(bb==2) {
    birdie->setLinearVelocity(b2Vec2(x+10,0));}
else if(bb==3){
eggbird->setLinearVelocity(b2Vec2(x+10,0));
}
else if(bb==4){
yellowbird->setLinearVelocity(b2Vec2(x+10,0));
}*/


    birdnum++;
    std::cout<<birdnum<<std::endl;
   mux=false;
   bb++;
   return true;

    }
 /*   if(event->type() == QEvent::MouseButtonRelease && mux){
         birdnum++;
        mux=false;

    }*/

    return false;
}




void MainWindow::closeEvent(QCloseEvent *)
{
    // Close event
    emit quitGame();
}

void MainWindow::tick()
{
    world->Step(1.0/60.0,6,2);
    scene->update();
}

void MainWindow::QUITSLOT()
{
    // For debugcloseEvent(QCloseEvent *)

        // Close event
      this->close();
    std::cout << "Quit Game Signal receive !" << std::endl ;
}
void MainWindow::keyPressEvent(QKeyEvent *event){
    if(event->key()==Qt::Key_R){
        restart();
    }
    else if(event->key()==Qt::Key_Q)
    {
quitGame();
       // qquit();
    }

}

void MainWindow::score(){

    int p1x,p1y,p2x,p2y,p3x,p3y;


        p1x = pig1->GetLinearVelocity().x;
            p1y = pig1->GetLinearVelocity().y;
            p2x = pig2->GetLinearVelocity().x;
                p2y = pig2->GetLinearVelocity().y;
                p3x = pig3->GetLinearVelocity().x;
                    p3y = pig3->GetLinearVelocity().y;
                    if(p1x)
                    {
                        count++;
                        //pig1->~QObject();
                        std::cout<<"score= "<<count<<std::endl;
                    }
                    else if(p2x)
                    {
                        count++;
                       // pig2->~QObject();
                        std::cout<<"score= "<<count<<std::endl;
                    }
                    else if(p3x)
                    {
                        count++;
                        //pig3->~QObject();
                        std::cout<<"score= "<<count<<std::endl;
                    }
}

void MainWindow::restart()
{
count=0;
    // Setting the QGraphicsScene
    scene = new QGraphicsScene(0,0,width(),ui->graphicsView->height());
    ui->graphicsView->setScene(scene);
    // Create world
    world = new b2World(b2Vec2(0.0f, -9.8f));
    // Setting Size
    GameItem::setGlobalSize(QSizeF(32,18),size());
    // Create ground (You can edit here)
    itemList.push_back(new Land(16,1.5,32,3,QPixmap(":/ground.png").scaled(width(),height()/6.0),world,scene));
   // itemList.push_back(new Land(3,3,5,5,QPixmap(":/image/horbarrier.png").scaled(width()/8,height()/6.0),world,scene));
    wwall_1 = new wall(20.0f,6.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_2 = new wall(20.0f,12.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_3 = new wall(10.0f,6.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_4 = new wall(15.0f,6.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_5 = new wall(20.0f,18.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    wwall_6 = new wall(30.0f,6.0f,2,3.0,&timer,QPixmap(":/image/verbarrier.png").scaled(30,80),world,scene);
    // Create bird (You can edit here)
    greenbird = new Bird(3.0f,5.0f,0.27f,&timer,QPixmap(":/image/GGbird.png").scaled(height()/9.0,height()/9.0),world,scene);

    pig1 = new Bird(22.0f,5.0f,0.27f,&timer,QPixmap(":/image/PPig.png").scaled(height()/9.0,height()/9.0),world,scene);
    pig2 = new Bird(23.0f,5.0f,0.27f,&timer,QPixmap(":/image/PPig.png").scaled(height()/9.0,height()/9.0),world,scene);
    pig3 = new Bird(12.0f,5.0f,0.27f,&timer,QPixmap(":/image/PPig.png").scaled(height()/9.0,height()/9.0),world,scene);
    // Setting the Velocity
  /*  if(eventFilter(birdie,QEvent::MouseButtonRelease)){
    birdie->setLinearVelocity(b2Vec2(x,y));
    }
    greenbird->setLinearVelocity(b2Vec2(0,0.1));*/

   // yellowbird->setLinearVelocity(b2Vec2(0,0.1));
    //eggbird->setLinearVelocity(b2Vec2(0,0.1));
   // pig->setLinearVelocity(b2Vec2(0,0.1));

   std::cout << "x="<<X1<<" "<<X2<<"y="<<Y1<<" "<<Y2<< std::endl ;
    itemList.push_back(birdie);
    // Timer
    connect(&timer,SIGNAL(timeout()),this,SLOT(tick()));
    connect(this,SIGNAL(quitGame()),this,SLOT(QUITSLOT()));
    timer.start(100/6);
  //  timer.start(100/speed);
}
/*void MainWindow::qquit(){
    close();

}

*/
